class RecentTransactionModel {
  final String title, monthText, dateText, amount, transaction;

  RecentTransactionModel(this.title, this.monthText, this.dateText, this.amount, this.transaction);

}
